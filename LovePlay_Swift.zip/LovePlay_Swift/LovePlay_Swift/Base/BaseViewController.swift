//
//  BaseViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/30.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backBtn = UIButton.init(type: .custom)
        backBtn.frame = CGRect.init(x: 0, y: 0, width: 50, height: 50)
        backBtn.setImage(UIImage.init(named: "back2_pgnews"), for: .normal)
        backBtn.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -30, bottom: 0, right: 0)
        
        backBtn.addTarget(self, action: #selector(baseBackAction), for: .touchUpInside)
        
        let backItem = UIBarButtonItem.init(customView: backBtn)
        
        self.navigationItem.leftBarButtonItem = backItem
        
    }
    
    @objc func baseBackAction(){
        _ = self.navigationController?.popViewController(animated: true)
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
