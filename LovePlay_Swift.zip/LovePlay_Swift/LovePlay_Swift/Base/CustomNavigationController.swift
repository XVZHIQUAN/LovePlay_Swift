//
//  CustomNavigationController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/28.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class CustomNavigationController: UINavigationController,UIGestureRecognizerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

//        self.setNavigationBarHidden(true, animated: true)
        self.interactivePopGestureRecognizer?.delegate = self
        
        configureNaviBarTheme()
        
        // Do any additional setup after loading the view.
    }

    fileprivate func configureNaviBarTheme(){
        self.navigationBar.tintColor = UIColor.white
        let textAttrs = [NSForegroundColorAttributeName:UIColor.white,NSFontAttributeName:UIFont.init(name: "Helvetica", size: 18)]
        self.navigationBar.titleTextAttributes = textAttrs
//        self.navigationBar.setBackgroundImage(UIImage.imageWithColor(color:RGB(R: 34, G: 34, B: 34, A: 1.0)), for: .default)
        
    }
    
    //MARK: -- UIGestureRecognizerDelegate
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        if self.viewControllers.count <= 1 {
            return false
        }
        return true
    }
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        if self.viewControllers.count >= 1 {
            viewController.hidesBottomBarWhenPushed = true
            let leftBarButtonItem = UIBarButtonItem.init(image: UIImage.init(named: "back2_pgnews"), style: .plain, target: self, action: #selector(backAction(item:)))
            viewController.navigationItem.leftBarButtonItem = leftBarButtonItem
        }
        super.pushViewController(viewController, animated: animated)
    }
    
    
    @objc func backAction(item:UIBarButtonItem){
        self.popViewController(animated: true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
