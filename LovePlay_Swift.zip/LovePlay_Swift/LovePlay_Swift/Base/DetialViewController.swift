//
//  DetialViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/30.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class DetialViewController: BaseViewController {

    public var urlString:String = ""
    public var newsTitle: String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = self.newsTitle
        
        self.view.backgroundColor = UIColor.white
        let webView = UIWebView.init(frame: self.view.bounds)
        self.view.addSubview(webView)
        webView.loadRequest(URLRequest.init(url: URL.init(string: self.urlString)!))
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
