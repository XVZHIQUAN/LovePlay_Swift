//
//  CustomTabbarController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/28.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class CustomTabbarController: UITabBarController {

    var titleArray:[String]?
    var classArray:[UIViewController]?
    var imageArray:[String]?
    var selectImageArray:[String]?
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        UIApplication.shared.isStatusBarHidden = false
        UIApplication.shared.statusBarStyle = .lightContent;
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tabBar.isTranslucent = false
        
        loadData()
        loadController()
        
        self.selectedIndex = 0
    }
    
    override func loadData(){
        titleArray = ["资讯","精选","社区","我的"]
        classArray = [NewsViewController(),GreatestHitsViewController(),CommunityViewController(),MineViewController()]
        imageArray = ["icon_zx_nomal_pgall","icon_jx_nomal_pgall","icon_sq_nomal_pgall","icon_w_nomal_pgall"]
        selectImageArray = ["icon_zx_pressed_pgall","icon_jx_pressed_pgall","icon_sq_pressed_pgall","icon_w_pressed_pgall"]
    }
    
    fileprivate func loadController(){
        var i = 0
        
        for vc:UIViewController in classArray! {
            configViewController(vc: vc, title: (titleArray?[i])!, image: (imageArray?[i])!, selectImage: (selectImageArray?[i])!)
            
            i += 1;
        }
        
    }
    
    
    fileprivate func configViewController(vc:UIViewController, title:String,image:String,selectImage:String){
        
        vc.title = title
        vc.tabBarItem.title = title
        vc.tabBarItem.image = UIImage(named:image)?.withRenderingMode(.alwaysOriginal)
        vc.tabBarItem.selectedImage = UIImage(named:selectImage)?.withRenderingMode(.alwaysOriginal)
        selectedTapTabBarItems(tabBarItem: vc.tabBarItem)
        unSelectedTapTabBarItems(tabBarItem: vc.tabBarItem)
        //       rootvc加在navc
        let navigationC = CustomNavigationController.init(rootViewController: vc)
        navigationC.navigationBar.barStyle = .black
        navigationC.navigationBar.isTranslucent = false
        
        self.addChildViewController(navigationC)
        
        //        CustomNavigationController *navigationC= [[CustomNavigationController alloc] initWithRootViewController:vc];
        //        navigationC.delegate = self;
        //        //        navc 加在tabbar上
        //        [self addChildViewController:navigationC];
    }
    
    
    
    
    
    func unSelectedTapTabBarItems(tabBarItem:UITabBarItem) {
        tabBarItem.setTitleTextAttributes([NSForegroundColorAttributeName:UIColor.gray,NSFontAttributeName:UIFont.systemFont(ofSize: 11.0)], for: .normal)
    }
    
    func selectedTapTabBarItems(tabBarItem:UITabBarItem) {
        tabBarItem.setTitleTextAttributes([NSForegroundColorAttributeName:UIColor.red,NSFontAttributeName:UIFont.systemFont(ofSize: 11.0)], for: .selected)
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
