//
//  NetAPI.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/29.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import Foundation
import Kingfisher

let baseURL = "http://i.play.163.com"
let NewsListURL = "/user/article/list/"
let NewsDetailURL = "/news/appDetail/"

let HotGameCommentURL = "/news/v2/hottie/"
let NewGameCommentURL = "/news/v2/newtie/"

let NewsRecommendTopicURL = "/news/topicOrderSource/list"
let NewsRecommendImageInfosURL = "/news/config/config_focus_img/list/"

let HotGameZoneURL = "/news/discuz/forum_recommend_detail"
let ZoneDiscuzURL = "/news/discuz/discuz_model_v2/list/center"
let DiscuzDetailURL = "http://bbs.d.163.com/api/mobile/index.php"
let ZoneDiscuzImageURL = "/news/discuz/discuz_model/fid_img"

