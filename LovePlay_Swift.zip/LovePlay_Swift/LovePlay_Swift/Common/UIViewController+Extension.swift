//
//  UIViewController+Extension.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/30.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController{
    func loadData(){
        
    }
}
