//
//  GreatestHitsModel.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/30.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class GreatestHitsModel: NSObject {
    var bannerUrl:String = ""
    var descri:String = ""
    var followUserCount:NSNumber = 0
    var hidden:NSNumber = 0
    var id:NSNumber = 0
    var idxpic:String = ""
    var ifOrder:Bool = false
    var newIcon:String = ""
    var newIconBgImg:String = ""
    var oprator:String = ""
    var orderSumNum:NSNumber = 0
    var topicIconRectangleUrl:String = ""
    var topicName:String = ""
    var topicId:String = ""
    var iconUrl:String = ""
    var sourceType:NSNumber = 0
    
    
    init(dict:[String:NSObject]) {
        super.init()
        setValuesForKeys(dict)
    }
    
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        if key == "description" {
            self.descri = value as! String
        }
    }
    
    
    
}
