//
//  GreatestBannerModel.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/30.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class GreatestBannerModel: NSObject {
    var address:String = ""
    var priority:NSNumber = 0
    var imgUrl:String = ""
    var docid:String = ""
    var subtitleOne:String = ""
    var subtitleTwo:String = ""
    var title:String = ""
 
    
    init(dict:[String:NSObject]) {
        super.init()
        setValuesForKeys(dict)
    }
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
}
