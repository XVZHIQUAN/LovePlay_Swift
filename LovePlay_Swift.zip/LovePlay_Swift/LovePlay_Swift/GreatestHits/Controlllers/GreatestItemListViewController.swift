//
//  GreatestItemListViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/1.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class GreatestItemListViewController: BaseViewController,UITableViewDataSource,UITableViewDelegate {

    
    fileprivate lazy var itemTabelView:UITableView = {
        let itemTabelView:UITableView = UITableView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: KScreen_H-64-49), style: .plain)
        itemTabelView.dataSource = self
        itemTabelView.delegate = self
        itemTabelView.register(HeadlineCell_1.self, forCellReuseIdentifier: "headline_1")
        itemTabelView.register(HeadlineCell_2.self, forCellReuseIdentifier: "headline_2")
        itemTabelView.register(SourceType_0Cell.self, forCellReuseIdentifier: "sourceType_0")
        
        return itemTabelView
    }()
    var page:Int = 0
    var listArray:[HeadlineModel] = [HeadlineModel]()
    
    var topicId:String = ""
    var sourceType:NSNumber = 0
    var titleString:String = ""
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = self.titleString
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(self.itemTabelView)
        
        refreshFooter()
        refreshHeader()
        
        loadData()
    }
    
    func refreshHeader() {
        //        self.headLineTabelView.mj_header = MJRefreshNormalHeader.init(refreshingTarget: self, refreshingAction: #selector(loadAgain))
        
        self.itemTabelView.mj_header = self.itemTabelView.gifHeader(refreshData: {
            loadAgain()
        })
    }
    func refreshFooter() {
        self.itemTabelView.mj_footer = MJRefreshAutoNormalFooter.init(refreshingTarget: self, refreshingAction: #selector(loadMoreData))
    }
    
    func loadAgain() {
        self.listArray.removeAll()
        self.page = 0
        loadData()
    }
    func loadMoreData() {
        self.page += 20
        loadData()
    }
    func endRefrsh() {
        self.itemTabelView.mj_footer.endRefreshing()
        self.itemTabelView.mj_header.endRefreshing()
    }
    
    
    override func loadData(){
        
        let urlString = "\(baseURL)" + "/" + "\(NewsListURL)" + "/" + "\(self.topicId)" + "/" + "\(self.page)" + "/" + "20"
        
        NetworkTools.requestData(.get, URLString: urlString, parameters: nil, finishedCallback: {result in
            
            guard let resultDict = result as? [String : NSObject] else {
                return
            }
            guard let info = resultDict["info"] as? [NSObject] else {
                return
            }
            //            let resultDict = result as? [String : NSObject]
            //            let info = (resultDict?["info"])! as! [NSObject]
            for dic in info{
                let model = HeadlineModel.init(dict: dic as! [String : NSObject])
                self.listArray.append(model)
            }
            print(self.listArray.count)
            self.itemTabelView.reloadData()
            self.endRefrsh()
            
        })
    }
    
    
    // MARK: - UITableViewDataSource
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return self.listArray.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        if indexPath.row < self.listArray.count {
            if self.sourceType == 0 {
                
                let model:HeadlineModel = self.listArray[indexPath.row]
                let cell = tableView.dequeueReusableCell(withIdentifier: "sourceType_0", for: indexPath) as! SourceType_0Cell
                cell.selectionStyle = .none
                cell.model = model
                return cell
                
            }else{
                let model:HeadlineModel = self.listArray[indexPath.row]
                if model.showType.isEqual(to: 5){
                    let cell = tableView.dequeueReusableCell(withIdentifier: "headline_1", for: indexPath) as! HeadlineCell_1
                    cell.selectionStyle = .none
                    cell.headlineModel = model
                    return cell
                }else{
                    let cell = tableView.dequeueReusableCell(withIdentifier: "headline_2", for: indexPath) as! HeadlineCell_2
                    cell.selectionStyle = .none
                    cell.headlineModel = model
                    return cell
                }
            }
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row < self.listArray.count {
            let model:HeadlineModel = self.listArray[indexPath.row]
            if self.sourceType == 0 {
                return 230
            }else{
                if model.showType.isEqual(to: 5){
                    return 90
                }else{
                    return 150
                }
            }
            
        }
        return 0
        
    }
    
    //MARK:- UITableViewDelegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row < self.listArray.count {
            let model:HeadlineModel = self.listArray[indexPath.row]
            let detialVC = DetialViewController()
            detialVC.urlString = model.url
            detialVC.newsTitle = model.title
            detialVC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(detialVC, animated: true)
            self.hidesBottomBarWhenPushed = false
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
