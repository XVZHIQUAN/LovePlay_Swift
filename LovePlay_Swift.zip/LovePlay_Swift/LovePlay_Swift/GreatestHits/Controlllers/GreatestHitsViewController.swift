//
//  GreatestHitsViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/28.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class GreatestHitsViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {

    let HeaderViewH:CGFloat = 150
    
    var listArray:[GreatestHitsModel] = [GreatestHitsModel]()
    
    fileprivate lazy var bannerView:GreatestHeaderBannnerView = {
        let bannerView:GreatestHeaderBannnerView = GreatestHeaderBannnerView.init(frame: CGRect.init(x: 0, y: -150, width: KScreen_W, height: 150))
        bannerView.backgroundColor = UIColor.white
        return bannerView
    }()
    
    fileprivate lazy var greatestHitsCollectionView:UICollectionView = {
       let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize.init(width: KScreen_W/3, height: KScreen_W/3)
        flowLayout.scrollDirection = .vertical
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        
        let greatestHitsCollectionView:UICollectionView = UICollectionView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: KScreen_H-64-49), collectionViewLayout: flowLayout)
        greatestHitsCollectionView.dataSource = self
        greatestHitsCollectionView.delegate = self
        greatestHitsCollectionView.showsVerticalScrollIndicator = false
        greatestHitsCollectionView.backgroundColor = UIColor.white
        
        greatestHitsCollectionView.register(GreatestHitsCell.self, forCellWithReuseIdentifier: "greate")
        
        greatestHitsCollectionView.contentInset = UIEdgeInsets.init(top: 150, left: 0, bottom: 0, right: 0)
        
        return greatestHitsCollectionView
    }()
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white
        
        loadUI()
        loadData()
    }

    //MARK:--UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return self.listArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "greate", for: indexPath) as! GreatestHitsCell
        
        cell.greateModel = self.listArray[indexPath.row]
        
        return cell
    }
    
    //MARK:--UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let model = self.listArray[indexPath.row]
        let itemlistVC = GreatestItemListViewController()
        itemlistVC.titleString = model.topicName
        itemlistVC.topicId = model.topicId
        itemlistVC.sourceType = model.sourceType
        itemlistVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(itemlistVC, animated: true)
        itemlistVC.hidesBottomBarWhenPushed = false
    }
    
    override func loadData() {
        
        let dGroup = DispatchGroup()
        
        dGroup.enter()
        let urlString:String = baseURL + "/" + NewsRecommendTopicURL
        
        NetworkTools.requestData(.get, URLString: urlString, parameters: nil, finishedCallback: { result in
            let resultDict = result as? [String : NSObject]
            let info = (resultDict?["info"])! as! [NSObject]
            for dic in info{
                let model = GreatestHitsModel.init(dict: dic as! [String : NSObject])
                self.listArray.append(model)
            }
            print(self.listArray.count)
            
            dGroup.leave()
            //self.greatestHitsCollectionView.reloadData()
        })
        
        
        dGroup.enter()
        let bannerUrlString = baseURL + NewsRecommendImageInfosURL
        var sArray:[GreatestBannerModel] = [GreatestBannerModel]()
        
        NetworkTools.requestData(.get, URLString: bannerUrlString, parameters: nil, finishedCallback: { result in
            let resultDict = result as? [String : NSObject]
            let info = (resultDict?["info"])! as! [NSObject]
            for dic in info{
                let model = GreatestBannerModel.init(dict: dic as! [String : NSObject])
                sArray.append(model)
            }
//            print(self.listArray.count)
            
            dGroup.leave()
            
        })
        
        
        dGroup.notify(queue: DispatchQueue.main) {
            self.bannerView.listArray = sArray
            self.greatestHitsCollectionView.reloadData()
        }
        
    }
    
    func loadUI() {
        self.view.addSubview(self.greatestHitsCollectionView)
        self.greatestHitsCollectionView.addSubview(self.bannerView)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
