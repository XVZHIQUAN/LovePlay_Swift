//
//  GreatestBannerCell.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/30.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class GreatestBannerCell: UICollectionViewCell {
    
    fileprivate var _greateBannerModel:GreatestBannerModel?
    var greateModel:GreatestBannerModel?{
        set{
            _greateBannerModel = newValue
            let url = URL(string:(_greateBannerModel?.imgUrl)!)
            self.icon.kf.setImage(with: url)
            
            self.titleLabel.text = _greateBannerModel?.title
        }
        get{
            return _greateBannerModel
        }
    }
    
    
    
    fileprivate lazy var icon:UIImageView = {
        let icon:UIImageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 300, height: 120))
        return icon
        
    }()
    
    fileprivate lazy var titleLabel:UILabel = {
        let titleLabel:UILabel = UILabel.init(frame: CGRect.init(x: 0, y: self.icon.bottom-20, width: self.icon.width, height: 20))
        titleLabel.textAlignment = .left
        titleLabel.font = UIFont.systemFont(ofSize: 14)
        titleLabel.textColor = UIColor.white
        return titleLabel
        
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        self.contentView.addSubview(self.icon)
        self.icon.addSubview(self.titleLabel)
    }
}
