//
//  SourceType_0Cell.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/1.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class SourceType_0Cell: UITableViewCell {

    
    fileprivate var _model:HeadlineModel?
    var model:HeadlineModel?{
        set{
            _model = newValue
            
            if (_model?.imgsrc.count)!>0 {
                let url = URL(string: (_model?.imgsrc[0])!)
                self.itemView.kf.setImage(with: url)
            }
            
            self.itemTitleLabel.text = _model?.title
            self.dateLabel.text = _model?.ptime
            self.commonCountLabel.text = _model?.replyCount.stringValue
        }
        get{
            return _model
        }
    }
    
    
    
    fileprivate lazy var itemView:UIImageView = {
       let itemView:UIImageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: 160))
        return itemView
    }()
    fileprivate lazy var itemTitleLabel:UILabel = {
        let itemTitleLabel:UILabel = UILabel.init(frame: CGRect.init(x: 10, y: self.itemView.bottom, width: KScreen_W-20, height: 40))
        itemTitleLabel.textColor = UIColor.black
        //itemTitleLabel.font = UIFont.systemFont(ofSize: 16)
        itemTitleLabel.numberOfLines = 0
        itemTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
        
        return itemTitleLabel
    }()
    
    fileprivate lazy var dateLabel:UILabel = {
        let dateLabel:UILabel = UILabel.init(frame: CGRect.init(x: 10, y: self.itemTitleLabel.bottom+5, width: (KScreen_W-20)/2, height: 15))
        dateLabel.textColor = UIColor.gray
        dateLabel.font = UIFont.systemFont(ofSize: 11)
        
        return dateLabel
    }()
    
    fileprivate lazy var commonICon:UIImageView = {
        let commonICon:UIImageView = UIImageView.init(frame: CGRect.init(x: self.itemTitleLabel.right-80-11, y: self.dateLabel.top, width: 11, height: 11))
        commonICon.image = UIImage.init(named: "common_chat_new")
        return commonICon
    }()
    
    fileprivate lazy var commonCountLabel:UILabel = {
        let commonCountLabel:UILabel = UILabel.init(frame: CGRect.init(x: self.commonICon.right + 10, y: self.commonICon.top, width: 80, height: self.commonICon.height))
        commonCountLabel.font = UIFont.systemFont(ofSize: 11)
        commonCountLabel.textColor = UIColor.gray
        return commonCountLabel
    }()
    
    
    func createUI() {
        self.contentView.addSubview(self.itemView)
        self.contentView.addSubview(self.itemTitleLabel)
        self.contentView.addSubview(self.dateLabel)
        self.contentView.addSubview(self.commonICon)
        self.contentView.addSubview(self.commonCountLabel)
    }
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
