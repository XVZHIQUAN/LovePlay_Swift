//
//  GreatestHitsCell.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/30.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class GreatestHitsCell: UICollectionViewCell {
    
    
    fileprivate var _greateModel:GreatestHitsModel?
    var greateModel:GreatestHitsModel?{
        set{
            _greateModel = newValue
            let url = URL(string:(_greateModel?.iconUrl)!)
            self.icon.kf.setImage(with: url)
            
            self.titleLabel.text = _greateModel?.topicName
        }
        get{
            return _greateModel
        }
    }
    
    
    
    fileprivate lazy var icon:UIImageView = {
        let icon:UIImageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 70, height: 70))
        icon.center = CGPoint.init(x: self.frame.size.width/2, y: (self.frame.size.height)/2)
        let layer = icon.layer
        layer.masksToBounds = true
        layer.cornerRadius = 70/2
        return icon
        
    }()
    
    fileprivate lazy var titleLabel:UILabel = {
        let titleLabel:UILabel = UILabel.init(frame: CGRect.init(x: 0, y: self.icon.bottom+5, width: self.frame.size.width, height: 20))
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont.systemFont(ofSize: 12)
        titleLabel.textColor = UIColor.black
        return titleLabel
        
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.backgroundColor = UIColor.white
        createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func createUI() {
        self.contentView.addSubview(self.icon)
        self.contentView.addSubview(self.titleLabel)
    }
}
