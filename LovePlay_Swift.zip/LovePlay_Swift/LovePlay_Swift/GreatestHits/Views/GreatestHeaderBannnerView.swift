//
//  GreatestHeaderBannnerView.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/30.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class GreatestHeaderBannnerView: UIView,UICollectionViewDataSource,UICollectionViewDelegate {

    fileprivate var _listArray:[GreatestBannerModel]?
    var listArray:[GreatestBannerModel]?{
        get{
            return _listArray
        }
        set{
            _listArray = newValue
            self.greatestHitsCollectionView.reloadData()
        }
    }
    
    
    fileprivate lazy var greatestHitsCollectionView:UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize.init(width: 300, height: 120)
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumLineSpacing = 10
        flowLayout.minimumInteritemSpacing = 0
        
        let greatestHitsCollectionView:UICollectionView = UICollectionView.init(frame: CGRect.init(x: 10, y: 0, width: self.width-20, height: 140), collectionViewLayout: flowLayout)
        greatestHitsCollectionView.dataSource = self
        greatestHitsCollectionView.delegate = self
        greatestHitsCollectionView.showsHorizontalScrollIndicator = false
        greatestHitsCollectionView.backgroundColor = UIColor.white
        
        greatestHitsCollectionView.register(GreatestBannerCell.self, forCellWithReuseIdentifier: "banner")
        
        return greatestHitsCollectionView
    }()
    

    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        if self.listArray != nil{
            return self.listArray!.count
        }
        return 0
    }
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "banner", for: indexPath) as! GreatestBannerCell
        
        if self.listArray != nil{
            cell.greateModel = self.listArray?[indexPath.row]
        }
        
        
        return cell
        
    }
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.greatestHitsCollectionView)
        
        let bottomView:UIView = UIView.init(frame: CGRect.init(x: 0, y: self.greatestHitsCollectionView.bottom, width: KScreen_W, height: 10))
        bottomView.backgroundColor = RGB(R: 242, G: 242, B: 242, A: 1)
        self.addSubview(bottomView)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
