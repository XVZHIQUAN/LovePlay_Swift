//
//  MineGiftCell.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/14.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class MineGiftCell: UITableViewCell {
    
    
    func createUI() {
        let titleArray = ["积分福利","游戏礼包"]
        let imageArray = ["mine_welfare_img","mine_gift_img"]
        
        for index in 0 ..< titleArray.count{
            let v = UIView.init(frame: CGRect.init(x: KScreen_W/2 * CGFloat(index), y: 0, width: KScreen_W/2, height: 73))
            v.backgroundColor = UIColor.white
            
            let l = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W/2-93, height: 20))
            l.center = CGPoint.init(x: 93/2, y: 73/2)
            l.textColor = UIColor.black
            l.font = UIFont.systemFont(ofSize: 16)
            l.textAlignment = .center
            l.text = titleArray[index]
            
            let picView = UIImageView.init(frame: CGRect.init(x:  v.width-93, y: 0, width: 93, height: 73))
            picView.image = UIImage.init(named: imageArray[index])
            
            
            v.addSubview(l)
            v.addSubview(picView)
            self.contentView.addSubview(v)
        }
        
        let midLine = UIView.init(frame: CGRect.init(x: KScreen_W-0.5, y: 0, width: 1, height: 73))
        midLine.backgroundColor = RGB(R: 242, G: 242, B: 242, A: 1)
        self.contentView.addSubview(midLine)
        
    }
    
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
