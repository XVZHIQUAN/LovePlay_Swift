//
//  MineViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/28.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class MineViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    let kHEIGHT:CGFloat = 169
    
    var headImageView:UIImageView?
    var userIcon:UIImageView?
    
    
    
    var titleArray = [["积分福利,游戏礼包"],["消息","任务","收藏","关注"],["设置","意见反馈"]]
    
    fileprivate lazy var mineTableView:UITableView = {
        let mineTableView:UITableView = UITableView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: KScreen_H-64-49), style: .plain)
        mineTableView.backgroundColor = RGB(R: 242, G: 242, B: 242, A: 1)
        mineTableView.dataSource = self
        mineTableView.delegate = self
        
        mineTableView.register(MineGiftCell.self, forCellReuseIdentifier: "gift")
        mineTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell_2")
        
        
        let footerView = UIView()
        footerView.backgroundColor = RGB(R: 242, G: 242, B: 242, A: 1)
        mineTableView.tableFooterView = footerView
        
        return mineTableView
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white
        self.view.addSubview(self.mineTableView)
        configHeaderView()
    }
    
    func configHeaderView() {
        self.mineTableView.contentInset = UIEdgeInsetsMake(kHEIGHT+30, 0, 0, 0)
        
        self.headImageView = UIImageView.init(frame: CGRect.init(x: 0, y: -kHEIGHT, width: KScreen_W, height: kHEIGHT))
        self.headImageView?.contentMode = .scaleAspectFill
        self.headImageView?.image = UIImage.init(named: "bg_pgmy")
        self.mineTableView.addSubview(self.headImageView!)
        
        self.userIcon = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 54, height: 54))
        self.userIcon?.center = CGPoint.init(x: KScreen_W/2, y: kHEIGHT/2+20)
        self.userIcon?.image = UIImage.init(named: "mine_main_default_head")
        self.headImageView?.addSubview(self.userIcon!)
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let point:CGPoint = scrollView.contentOffset;
        if (point.y < -kHEIGHT) {
            var rect:CGRect = (self.headImageView?.frame)!
            rect.origin.y = point.y
            rect.size.height = -point.y
            self.headImageView?.frame = rect
            
            self.userIcon?.center = CGPoint.init(x: KScreen_W/2, y: (self.headImageView?.height)!/2+20)
            
        }
    }
    
    
    public func numberOfSections(in tableView: UITableView) -> Int{
        return self.titleArray.count
    }
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        let arr = self.titleArray[section]
        return arr.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "gift", for: indexPath) as! MineGiftCell
            
            return cell
        }else{
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell_2", for: indexPath)
            let arr = self.titleArray[indexPath.section]
            cell.accessoryType = .disclosureIndicator
            
            cell.textLabel?.text = arr[indexPath.row]
            
            return cell
            
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 73
        }else{
            return 50
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


