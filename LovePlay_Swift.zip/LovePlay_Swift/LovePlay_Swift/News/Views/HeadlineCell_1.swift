//
//  HeadlineCell_1.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/29.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class HeadlineCell_1: UITableViewCell {


    fileprivate lazy var imgView:UIImageView = {
       let imgView = UIImageView.init(frame: CGRect.init(x: 10, y: 10, width: 100, height: 70))
        
        return imgView
    }()
    
    fileprivate lazy var titleLabel:UILabel = {
        let titleLabel:UILabel = UILabel.init(frame: CGRect.init(x: self.imgView.right + 10, y: 10, width: KScreen_W - self.imgView.right - 20, height: 50))
        titleLabel.font = UIFont.systemFont(ofSize: 16)
        titleLabel.textColor = UIColor.black
        titleLabel.numberOfLines = 0
        return titleLabel
    }()
    
    fileprivate lazy var commonICon:UIImageView = {
        let commonICon:UIImageView = UIImageView.init(frame: CGRect.init(x: self.titleLabel.left, y: self.imgView.bottom-11, width: 11, height: 11))
        commonICon.image = UIImage.init(named: "common_chat_new")
        return commonICon
    }()
    
    fileprivate lazy var commonCountLabel:UILabel = {
        let commonCountLabel:UILabel = UILabel.init(frame: CGRect.init(x: self.commonICon.right + 10, y: self.commonICon.top, width: 150, height: self.commonICon.height))
        commonCountLabel.font = UIFont.systemFont(ofSize: 11)
        commonCountLabel.textColor = UIColor.gray
        return commonCountLabel
    }()
    
    
    fileprivate var _headlineModel:HeadlineModel?
    var headlineModel:HeadlineModel?{
        set{
            _headlineModel = newValue
            
            if (_headlineModel?.imgsrc.count)!>0 {
                let url = URL(string: (_headlineModel?.imgsrc[0])!)
                self.imgView.kf.setImage(with: url)
            }
            
            
            self.titleLabel.text = _headlineModel?.title
            let h = CommonTool.getTextRectSize(text:(_headlineModel?.title)!, font: self.titleLabel.font, size: CGSize.init(width: self.titleLabel.width, height: CGFloat(MAXFLOAT)))
            self.titleLabel.height = h
            
            
            self.commonCountLabel.text = _headlineModel?.replyCount.stringValue
            
        }
        get{
            return _headlineModel;
        }
    }
    
    
    
    
    
    
    func loadUI() {
        self.contentView.addSubview(self.imgView)
        self.contentView.addSubview(self.titleLabel)
        self.contentView.addSubview(self.commonICon)
        self.contentView.addSubview(self.commonCountLabel)
    }
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        loadUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
