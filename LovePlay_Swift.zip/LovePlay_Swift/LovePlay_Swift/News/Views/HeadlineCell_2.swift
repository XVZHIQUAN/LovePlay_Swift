//
//  HeadlineCell_2.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/29.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class HeadlineCell_2: UITableViewCell {

    fileprivate lazy var titleLabel:UILabel = {
        let titleLabel:UILabel = UILabel.init(frame: CGRect.init(x: 10, y: 5, width: KScreen_W - 20, height: 20))
        titleLabel.font = UIFont.systemFont(ofSize: 16)
        titleLabel.textColor = UIColor.black
        return titleLabel
    }()
    
    fileprivate lazy var imgView:UIImageView = {
        let imgView = UIImageView.init(frame: CGRect.init(x: 10, y: 30, width: KScreen_W-20, height: 110))
        
        return imgView
    }()
    
    fileprivate var _headlineModel:HeadlineModel?
    var headlineModel:HeadlineModel?{
        set{
            _headlineModel = newValue
            
            if (_headlineModel?.imgsrc.count)!>0 {
                let url = URL(string: (_headlineModel?.imgsrc[0])!)
                self.imgView.kf.setImage(with: url)
            }
            
            self.titleLabel.text = _headlineModel?.title
        }
        get{
            return _headlineModel;
        }
    }
    
    
    func loadUI() {
        self.contentView.addSubview(self.titleLabel)
        self.contentView.addSubview(self.imgView)
        
    }
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        loadUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
