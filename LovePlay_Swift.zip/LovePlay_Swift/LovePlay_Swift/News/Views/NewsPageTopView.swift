//
//  NewsPageTopView.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/29.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

protocol NewsPageTopViewDelegate {
    func newsPageTopViewWithTag(view:NewsPageTopView,tag:Int)
}

class NewsPageTopView: UIView {

    
    let selectBottomLine:UIView = UIView()
    var currentSelectedBtn:UIButton?
    var delegate:NewsPageTopViewDelegate?
    var titleArray:[String] = [String]()
    
    
    init(frame: CGRect, titleArray:[String]) {
        self.titleArray = titleArray
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
//        let titleArray = ["头条","网游","手游","主机","电竞","暴雪"]
        let btnW = self.frame.width/CGFloat(self.titleArray.count)
        
        for (index,title) in self.titleArray.enumerated() {
            let btn = UIButton.init(type: .custom)
            btn.frame = CGRect.init(x: btnW*CGFloat(index), y: 0, width: btnW, height: 42)
            btn.setTitle(title, for: .normal)
            btn.setTitleColor(UIColor.white, for: .normal)
            btn.setTitleColor(RGB(R: 242, G: 90, B: 65, A: 1), for: .selected)
            btn.titleLabel?.textAlignment = .center
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
            btn.tag = 10 + index
            btn.addTarget(self, action: #selector(btnClickAction(btn:)), for: .touchUpInside)
            self.addSubview(btn)
            if index == 0 {
                btn.isSelected = true
                self.currentSelectedBtn = btn
                self.currentSelectedBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 18)
                
                self.selectBottomLine.frame = CGRect.init(x: 5, y: btn.bottom, width: btnW-10, height: 2)
                self.selectBottomLine.backgroundColor = RGB(R: 242, G: 90, B: 65, A: 1)
                self.addSubview(self.selectBottomLine)
                
            }
            
        }
        
        
    }
    
    @objc fileprivate func btnClickAction(btn:UIButton){
        self.currentSelectedBtn?.isSelected = false
        self.currentSelectedBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        self.currentSelectedBtn = btn
        self.currentSelectedBtn?.isSelected = true
        self.currentSelectedBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        
        UIView.animate(withDuration: 0.5, animations: {
            self.selectBottomLine.left = btn.left+5
        })
        
        if self.delegate != nil {
            self.delegate?.newsPageTopViewWithTag(view: self, tag: btn.tag-10)
        }
    }
    
    open func selectOnePage(pageIndex:Int) {
        self.currentSelectedBtn?.isSelected = false
        self.currentSelectedBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        
        let btn:UIButton = (self.viewWithTag(pageIndex+10) as! UIButton)
        
        self.currentSelectedBtn = btn
        self.currentSelectedBtn?.isSelected = true
        self.currentSelectedBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        
        UIView.animate(withDuration: 0.5, animations: {
            self.selectBottomLine.left = btn.left+5
        })
    }
    
    

}
