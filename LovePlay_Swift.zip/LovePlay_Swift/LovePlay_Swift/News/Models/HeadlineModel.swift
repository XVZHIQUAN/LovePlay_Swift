//
//  HeadlineModel.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/29.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class HeadlineModel: NSObject {
    var articleTags:String = ""
    var boardid:String = ""
    var digest:String = ""
    var docid:String = ""
    var fromTopicSource:Bool = false
    var gameName:String = ""
    var id:NSNumber = 0
    var imgsrc:[String] = [String]()
    var lmodify:String = ""
    var photosetId:String = ""
    var priority:NSNumber = 0
    var ptime:String = ""
    var readSeconds:NSNumber = 0
    var replyCount:NSNumber = 0
    var showType:NSNumber = 0
    var specialId:String = ""
    var source:String = ""
    var subtitle:String = ""
    var title:String = ""
    var topicName:String = ""
    var url:String = ""
    var userId:NSNumber = 0
    var userOrder:Bool = false
    
    init(dict:[String:NSObject]) {
        super.init()
        setValuesForKeys(dict)
    }
    
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
    
    
    
}
