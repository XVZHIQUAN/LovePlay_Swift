//
//  NewsViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/28.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class NewsViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,NewsPageTopViewDelegate {

    
    fileprivate lazy var cuNavcView:UIView = {
        let cuNavcView:UIView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: 64))
        cuNavcView.backgroundColor = UIColor.black
        return cuNavcView
    }()
    
    fileprivate lazy var topView:NewsPageTopView = {
//        let topView = NewsPageTopView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: 44))
        let topView = NewsPageTopView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: 44), titleArray: ["头条","网游","手游","主机","电竞","暴雪"])
        topView.delegate = self
        return topView
    }()
    
    fileprivate lazy var newsCollectionView:UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize.init(width: KScreen_W, height: KScreen_H-64-49)
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        
        let newsCollectionView = UICollectionView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: KScreen_H-64-49), collectionViewLayout: flowLayout)
        newsCollectionView.backgroundColor = UIColor.white
        newsCollectionView.dataSource = self
        newsCollectionView.delegate = self
        newsCollectionView.showsVerticalScrollIndicator = false
        newsCollectionView.showsHorizontalScrollIndicator = false
        newsCollectionView.isPagingEnabled = true
        newsCollectionView.bounces = false
        
        newsCollectionView.register(NewsVCCell.self, forCellWithReuseIdentifier: "newsVC")
        
       return newsCollectionView
    }()
    
    fileprivate var vcArray:[UIViewController] = {
        let vcArray:[UIViewController] = [HeadlineViewController(),NetGameViewController(),HandGameViewController(),MainMechineViewController(),ECViewController(),StormViewController()]

        
        return vcArray
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white
        self.navigationItem.titleView = self.topView
        //configNavTopPageView()
        loadUI()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        self.navigationController?.navigationBar.isHidden = true
//        configNavTopPageView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
//        self.navigationController?.navigationBar.isHidden = false
//        self.cuNavcView.removeFromSuperview()
        
    }
    
    //MARK: - NewsPageTopViewDelegate

    func newsPageTopViewWithTag(view: NewsPageTopView, tag: Int) {
        self.newsCollectionView.scrollToItem(at: IndexPath.init(row: tag, section: 0), at: .centeredHorizontally, animated: true)
    }
    
    
    //MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return self.vcArray.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "newsVC", for: indexPath) as! NewsVCCell
        
        for view:UIView in cell.contentView.subviews {
            view.removeFromSuperview()
        }
        
        cell.cellVC = self.vcArray[indexPath.row]
        cell.cellVC?.view.frame = CGRect.init(x: 0, y: 0, width: KScreen_W, height: self.view.height)
        cell.contentView.addSubview((cell.cellVC?.view)!)
        
        return cell
    }
    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let offset = self.newsCollectionView.contentOffset.x/KScreen_W
        self.topView.selectOnePage(pageIndex: Int(offset))
    }
    
    
    
    func loadUI() {
        self.view.addSubview(self.newsCollectionView)
        for vc:UIViewController in self.vcArray {
            self.addChildViewController(vc)
        }
    }
    func configNavTopPageView() {
//        self.title = ""
        self.view.addSubview(self.cuNavcView)
        self.cuNavcView.addSubview(self.topView)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
