//
//  HeadlineViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/29.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class HeadlineViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    static let shareVC = HeadlineViewController()
    
    fileprivate lazy var headLineTabelView:UITableView = {
        let headLineTabelView:UITableView = UITableView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: KScreen_H-64-49), style: .plain)
        headLineTabelView.dataSource = self
        headLineTabelView.delegate = self
        headLineTabelView.register(HeadlineCell_1.self, forCellReuseIdentifier: "headline_1")
        headLineTabelView.register(HeadlineCell_2.self, forCellReuseIdentifier: "headline_2")
        
        return headLineTabelView
    }()
    var page:Int = 0
    var listArray:[HeadlineModel] = [HeadlineModel]()
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white
        self.view.addSubview(self.headLineTabelView)
        
        refreshFooter()
        refreshHeader()
        
        loadData()
    }

    func refreshHeader() {
//        self.headLineTabelView.mj_header = MJRefreshNormalHeader.init(refreshingTarget: self, refreshingAction: #selector(loadAgain))
        
        self.headLineTabelView.mj_header = self.headLineTabelView.gifHeader(refreshData: {
            loadAgain()
        })
    }
    func refreshFooter() {
        self.headLineTabelView.mj_footer = MJRefreshAutoNormalFooter.init(refreshingTarget: self, refreshingAction: #selector(loadMoreData))
    }
    
    func loadAgain() {
        self.listArray.removeAll()
        self.page = 0
        loadData()
    }
    func loadMoreData() {
        self.page += 20
        loadData()
    }
    func endRefrsh() {
        self.headLineTabelView.mj_footer.endRefreshing()
        self.headLineTabelView.mj_header.endRefreshing()
    }

    
    override func loadData(){
        let urlString = "\(baseURL)" + "/" + "\(NewsListURL)" + "/" + "\(self.page)" + "/" + "20"
        
        NetworkTools.requestData(.get, URLString: urlString, parameters: nil, finishedCallback: {result in
            
            guard let resultDict = result as? [String : NSObject] else {
                return
            }
            guard let info = resultDict["info"] as? [NSObject] else {
                return
            }
//            let resultDict = result as? [String : NSObject]
//            let info = (resultDict?["info"])! as! [NSObject]
            for dic in info{
                let model = HeadlineModel.init(dict: dic as! [String : NSObject])
                self.listArray.append(model)
            }
            print(self.listArray.count)
            self.headLineTabelView.reloadData()
            self.endRefrsh()
            
        })
    }
    
    
    // MARK: - UITableViewDataSource
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return self.listArray.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        if indexPath.row < self.listArray.count {
            let model:HeadlineModel = self.listArray[indexPath.row]
            if model.showType.isEqual(to: 5){
                let cell = tableView.dequeueReusableCell(withIdentifier: "headline_1", for: indexPath) as! HeadlineCell_1
                cell.selectionStyle = .none
                cell.headlineModel = model
                return cell
            }else{
                let cell = tableView.dequeueReusableCell(withIdentifier: "headline_2", for: indexPath) as! HeadlineCell_2
                cell.selectionStyle = .none
                cell.headlineModel = model
                return cell
            }
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row < self.listArray.count {
            let model:HeadlineModel = self.listArray[indexPath.row]
            if model.showType.isEqual(to: 5){
                return 90
            }else{
                return 150
            }
        }
        return 0
        
    }
    
    //MARK:- UITableViewDelegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row < self.listArray.count {
            let model:HeadlineModel = self.listArray[indexPath.row]
            let detialVC = DetialViewController()
            detialVC.urlString = model.url
            detialVC.newsTitle = model.title
            detialVC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(detialVC, animated: true)
            self.hidesBottomBarWhenPushed = false
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
