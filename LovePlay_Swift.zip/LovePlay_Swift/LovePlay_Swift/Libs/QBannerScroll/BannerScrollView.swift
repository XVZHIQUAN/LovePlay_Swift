//
//  BannerScrollView.swift
//  ScrollBanner_Swift
//
//  Created by zhiquan.xu on 16/11/21.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit
import Kingfisher

//MARK: -- 代理
protocol BannerScrollViewDelegate {
    func bannerScrollView(_ bannerScrollView: BannerScrollView, didSelectItemAt indexPath: IndexPath)
}

//MARK: -- pageControl位置
enum BannerScrollViewPageControlPosition {
    case left
    case center
    case right
}

class BannerScrollView: UIView,UICollectionViewDataSource,UICollectionViewDelegate {

    // MARK: -- 自定义属性
    var newBannerImageArray:[String]?//图片数组
    
    var bannerTimer:BannerScrollTimer?//定时器
    fileprivate let BAutoScroll:Bool? //是否可以滚动
    fileprivate let cellID:String = "bannerScrollID"
    
    var scrollIndex:Int = 0
    
    var delegate:BannerScrollViewDelegate?//代理
    
    
    //设置pageControl的颜色和当前颜色
    fileprivate var _currentPageControlTintColor:UIColor = UIColor.red
    var currentPageControlTintColor:UIColor{
        set{
            _currentPageControlTintColor = newValue
            
            pageControl.currentPageIndicatorTintColor = _currentPageControlTintColor
        }
        get{
            return _currentPageControlTintColor
        }
    }
    
    fileprivate var _pageTintColor:UIColor = UIColor.white
    var pageTintColor:UIColor{
        set{
            _pageTintColor = newValue
            pageControl.pageIndicatorTintColor = _pageTintColor
        }
        get{
            return _pageTintColor
        }
    }
    
    
    
    
    //是否隐藏pageControl
    fileprivate var _isHidePageControl:Bool = false
    var isHidePageControl:Bool{
        set{
            _isHidePageControl = newValue
            pageControl.isHidden = isHidePageControl
        }
        get{
            return _isHidePageControl;
        }
    }
    
    
    //pageControl位置 默认中间
    fileprivate var _pageControlPosition:BannerScrollViewPageControlPosition = .center
    var pageControlPosition:BannerScrollViewPageControlPosition{
        set{
            _pageControlPosition = newValue
            let pW = getPageControlSize().width
            
            if _pageControlPosition == .left {
                pageControl.frame = CGRect.init(x: 15, y: self.frame.height-30, width: pW, height: 30)
            }else if _pageControlPosition == .center{
                pageControl.frame = CGRect.init(x: 0, y: 0, width: pW, height: 30)
                pageControl.center = CGPoint.init(x: self.frame.width/2, y: self.frame.height-15)
            }else{
                pageControl.frame = CGRect.init(x: self.frame.width - 15 - pW, y: self.frame.height-30, width: pW, height: 30)
            }
        }
        get{
            return _pageControlPosition;
        }
    }
    
    
    
    
    fileprivate var _bannerImageArray:[String]?
    var bannerImageArray:[String]?{
        set{
            _bannerImageArray = newValue;
            
            newBannerImageArray = _bannerImageArray;
            if newBannerImageArray?.count == 1 {
                
                self.collectionView.reloadData()
                pageControl.isHidden = true
                self.bannerTimer?.stopTimer()
                
                return
            }
            
            //对数组数据进行处理
            if (_bannerImageArray?.count)! > 0 {
                newBannerImageArray?.insert((_bannerImageArray?.last)!, at: 0)
                newBannerImageArray?.append((_bannerImageArray?.first)!)
                self.collectionView.reloadData()
                
                if self.scrollIndex == 0 {//第一次赋值并加载
                   self.collectionView.setContentOffset(CGPoint.init(x: self.frame.width, y: 0), animated: true)
                }else{
                    if self.scrollIndex < (self.newBannerImageArray?.count)! {
                        //避免重新赋值后从“0”开始
                        changeScrollWithIndex(page: self.scrollIndex)
                    }else{//当banner数组发生变化，重新从“0”开始
                        self.collectionView.setContentOffset(CGPoint.init(x: self.frame.width, y: 0), animated: true)
                    }
                    
                }
//                self.collectionView.setContentOffset(CGPoint.init(x: self.frame.width, y: 0), animated: true)
                
                pageControl.numberOfPages = (newBannerImageArray?.count)! - 2
            }
            openTimer()
            
        }
        get{
            return _bannerImageArray;
        }
    }
    
    //时间间隔，默认2 S
    fileprivate var _timeInterval:TimeInterval = 2
    var timeInterval:TimeInterval{
        set{
            _timeInterval = newValue
            self.bannerTimer?.timeInterval = _timeInterval
        }
        get{
            return _timeInterval
        }
    }
    
    
    //MARK: --  懒加载
    fileprivate lazy var collectionView : UICollectionView = {
        
        let flowLayout = UICollectionViewFlowLayout();
        flowLayout.itemSize = CGSize.init(width: self.frame.size.width, height: self.frame.size.height)
        
        
        let collectionView = UICollectionView(frame: self.frame, collectionViewLayout: flowLayout);
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.isPagingEnabled = true
        
        return collectionView;
        
    }()
    
    fileprivate lazy var pageControl:UIPageControl = {
        let pageControl = UIPageControl()
        pageControl.frame = CGRect.init(x: 0, y: 0, width: self.frame.width, height: 30)
        pageControl.center = CGPoint.init(x: self.frame.width/2, y: self.frame.height-15)
        pageControl.currentPageIndicatorTintColor = UIColor.red
        pageControl.pageIndicatorTintColor = UIColor.white
        
        return pageControl
    }()
    
    
    override func layoutSubviews() {
        //设置layout(获取的尺寸准确，所以在这里设置)
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = collectionView.bounds.size
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.isPagingEnabled = true
        //设置该空间不随着父控件的拉伸而拉伸
        autoresizingMask = UIViewAutoresizing()
    }
    
    // MARK: -- 构造方法
    init (frame:CGRect,AutoScroll:Bool) {
        
        self.BAutoScroll = AutoScroll;
        self.bannerTimer = BannerScrollTimer.shareTimer
        super.init(frame: frame);
        createUI();
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(frame: CGRect,AutoScroll:Bool,bannerImageArray:[String]) {
        self.BAutoScroll = AutoScroll;
        self.bannerTimer = BannerScrollTimer.shareTimer
        super.init(frame: frame)
        self.bannerImageArray = bannerImageArray
        createUI();
        
    }
    
    
    // MARK: -- UI
    func createUI() {

        self.addSubview(collectionView)
        self.addSubview(pageControl)
        
        
        collectionView.register(BannerScrollCell.self, forCellWithReuseIdentifier: cellID)
        if (self.BAutoScroll! && newBannerImageArray != nil){
            openTimer()
        }
        
    }
    
    fileprivate func openTimer() {
        self.bannerTimer?.startTimer()
        weak var weakSelf = self
        self.bannerTimer?.timerBlock = {
            weakSelf?.collectionView.setContentOffset(CGPoint.init(x: (weakSelf?.frame.width)!+(weakSelf?.collectionView.contentOffset.x)!, y: 0), animated: true)
        }
    }
    
    
    //MARK: -- UICollectionViewDataSource
    public func collectionView(_ collectionView: UICollectionView,  numberOfItemsInSection section: Int) -> Int{
        if newBannerImageArray != nil {
            return (newBannerImageArray?.count)!
        }
        return 0
        
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellID, for: indexPath) as! BannerScrollCell
        
//        cell.scrollImage?.image = UIImage(named: newBannerImageArray![indexPath.row])
        let url = URL(string: newBannerImageArray![indexPath.row])
        cell.scrollImage?.kf.setImage(with: url)
//        print(newBannerImageArray![indexPath.row])
        
        return cell
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if (delegate != nil) {
            var nIn:IndexPath?
            if newBannerImageArray?.count == 1 {
                nIn = IndexPath.init(item: indexPath.row, section: indexPath.section)
            }else{
                nIn = IndexPath.init(item: indexPath.row-1, section: indexPath.section)
            }
            
            delegate?.bannerScrollView(self, didSelectItemAt: nIn!)
        }
    }
    
    //MARK: -- UIScrollViewDelegate
    public func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.bannerTimer?.stopTimer()
    }
    public func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
       let page = collectionView.contentOffset.x/self.frame.size.width;
        self.scrollIndex = Int(page);
        changeScrollWithIndex(page: self.scrollIndex);
        //拖动结束时，重新开启定时器定时器
        
        self.bannerTimer?.startTimer()
    }
    public func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        let page = self.collectionView.contentOffset.x/self.frame.width;
        self.scrollIndex = Int(page);
        changeScrollWithIndex(page: self.scrollIndex)
    }
    
    public func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let page = collectionView.contentOffset.x/self.frame.size.width;
        self.scrollIndex = Int(page);
        changeScrollWithIndex(page: self.scrollIndex)
    }
    
    func changeScrollWithIndex(page:Int){
        if (page == 0) {
            self.scrollIndex = (_bannerImageArray?.count)!;
            self.collectionView.setContentOffset(CGPoint.init(x: self.frame.width*(CGFloat)(self.scrollIndex - 1), y: 0), animated: false)
        }
        if (page == (_bannerImageArray?.count)!+1){
            self.scrollIndex = 1;
            self.collectionView.setContentOffset(CGPoint.init(x: self.frame.width, y: 0), animated: false)
        }
        pageControl.currentPage = self.scrollIndex-1;
    }
    
    fileprivate func getPageControlSize() -> CGSize {
        if pageControl.numberOfPages == 0 {
            return CGSize.init(width: 90, height: 30)
        }
        let pSize = pageControl.size(forNumberOfPages: pageControl.numberOfPages)
        
        return pSize
    }

}
