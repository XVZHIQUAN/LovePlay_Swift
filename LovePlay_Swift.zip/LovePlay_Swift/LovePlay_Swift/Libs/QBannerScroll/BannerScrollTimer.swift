//
//  BannerScrollTimer.swift
//  ScrollBanner_Swift
//
//  Created by zhiquan.xu on 16/11/21.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

typealias BannerScrollTimerBlock = () -> Void

class BannerScrollTimer: NSObject {
    
    //MARK -- 属性
    var timer:Timer?
    fileprivate var _timeInterval:TimeInterval = 2
    var timeInterval:TimeInterval{
        set{
            _timeInterval = newValue;
            stopTimer()
            startTimer()
        }
        get{
            return _timeInterval
        }
    }
    
    
    //闭包
    var timerBlock:BannerScrollTimerBlock = {()->()in
        
    }
    
    
    
    //MARK -- method
    static let shareTimer = BannerScrollTimer()
    override init() {
        
    }
    
    func startTimer(){
        stopTimer()
        weak var weakSelf = self
         weakSelf?.timer = Timer(timeInterval: _timeInterval, repeats: true, block: {(timer) in
            weakSelf!.update()
        })
        RunLoop.main.add(self.timer!, forMode: .commonModes)

        
    }
    
    func stopTimer() {
        self.timer?.invalidate()
        
    }
    
    func update() {
        self.timerBlock()
        
    }
    
}
