//
//  BannerScrollCell.swift
//  ScrollBanner_Swift
//
//  Created by zhiquan.xu on 16/11/21.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class BannerScrollCell: UICollectionViewCell {
    
    var scrollImage:UIImageView?
    
    
    override init(frame:CGRect){
        super.init(frame: frame)
        
        self.scrollImage = UIImageView(frame:self.bounds)
        self.contentView.addSubview(self.scrollImage!)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
