//
//  HotRecommonModel.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/9.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class HotRecommonModel: NSObject {
    var author:String = ""
    var authorid:String = ""
    var dateline:String = ""
    var digest:String = ""
    var fid:String = ""
    var fname:String = ""
    var headImg:String = ""
    var highlight:String = ""
    var lastpost:String = ""
    var lastposter:String = ""
    var replies:String = ""
    var subject:String = ""
    var tid:String = ""
    var title:String = ""
    var typeid:String = ""
    var typename:String = ""
    var views:String = ""
    
    var titleSize:CGSize = CGSize.init()
    var cellHeight:CGFloat = 0
    
    
    func getTitleHeight(){
        let h = CommonTool.getTextRectSize(text: self.title, font: UIFont.systemFont(ofSize: 16), size: CGSize.init(width: KScreen_W-20, height: CGFloat(MAXFLOAT)))
        self.titleSize = CGSize.init(width: KScreen_W-20, height: h)
        self.cellHeight = 5 + h + 10 + 10 + 15
    }
    
    
    
    init(dict:[String:NSObject]) {
        super.init()
        setValuesForKeys(dict)
        getTitleHeight()
    }
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
    
}
