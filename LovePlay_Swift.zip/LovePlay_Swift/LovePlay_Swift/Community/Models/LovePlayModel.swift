//
//  LovePlayModel.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/12.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class LovePlayModel: NSObject {
    var bannerUrl:String = ""
    var discuzModelTypeId:NSNumber = 0
    var fid:NSNumber = 0
    var iconUrl:String = ""
    var modelDesc:String = ""
    var modelName:String = ""
    var posts:NSNumber = 0
    var recommendList:NSNumber = 0
    var specialRedirect:NSNumber = 0
    var threads:NSNumber = 0
    var todayPosts:NSNumber = 0
    var top:NSNumber = 0
    var weight:NSNumber = 0
    
    init(dict:[String:NSObject]) {
        super.init()
        setValuesForKeys(dict)
    }
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
    
}
