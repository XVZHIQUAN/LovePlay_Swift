//
//  LovePlayCell.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/12.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class LovePlayCell: UICollectionViewCell {
    
    
    fileprivate var _lovePlayModel:LovePlayModel?
    var lovePlayModel:LovePlayModel?{
        set{
            _lovePlayModel = newValue
            
            let url = URL(string: (_lovePlayModel?.iconUrl)!)
            self.iconView.kf.setImage(with: url)
            
            self.modelNameLabel.text = _lovePlayModel?.modelName
            self.modelDescLabel.text = _lovePlayModel?.modelDesc
        }
        get{
            return _lovePlayModel
        }
    }
    

    
    
    
    fileprivate lazy var iconView:UIImageView = {
        let iconView:UIImageView = UIImageView.init(frame: CGRect.init(x: 10, y: 10, width: 60, height: 60))
        
        let layer:CALayer = iconView.layer
        layer.cornerRadius = 60/2
        layer.masksToBounds = true
        
        return iconView
    }()
    
    fileprivate lazy var modelNameLabel:UILabel = {
        let modelNameLabel:UILabel = UILabel.init(frame: CGRect.init(x: self.iconView.right+10, y: 15, width: KScreen_W/2-self.iconView.right-10, height: 20))
        modelNameLabel.textColor = UIColor.black
        modelNameLabel.font = UIFont.systemFont(ofSize: 15)
        return modelNameLabel
    }()
    fileprivate lazy var modelDescLabel:UILabel = {
        let modelDescLabel:UILabel = UILabel.init(frame: CGRect.init(x: self.iconView.right+10, y: self.iconView.bottom-10-10, width: KScreen_W/2-self.iconView.right-10, height: 10))
        modelDescLabel.textColor = UIColor.gray
        modelDescLabel.font = UIFont.systemFont(ofSize: 11)
        return modelDescLabel
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.layer.borderColor = RGB(R: 242, G: 242, B: 242, A: 1).cgColor
        self.layer.borderWidth = 1
        self.contentView.addSubview(self.iconView)
        self.contentView.addSubview(self.modelNameLabel)
        self.contentView.addSubview(self.modelDescLabel)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
