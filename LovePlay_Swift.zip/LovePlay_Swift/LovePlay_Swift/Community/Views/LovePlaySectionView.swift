//
//  LovePlaySectionView.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/12.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class LovePlaySectionView: UICollectionReusableView {
    lazy var titleLabel:UILabel = {
        let titleLabel:UILabel = UILabel.init(frame: CGRect.init(x: 10, y: 5, width: KScreen_W-20, height: 20))
        titleLabel.textColor = UIColor.black
        return titleLabel
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = RGB(R: 242, G: 242, B: 242, A: 1)
        self.addSubview(titleLabel)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
