//
//  HotRecommonCell.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/9.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class HotRecommonCell: UITableViewCell {

    
    fileprivate var _hotRecommonModel:HotRecommonModel?
    var hotRecommonModel:HotRecommonModel?{
        get{
            return _hotRecommonModel;
        }
        set{
            _hotRecommonModel = newValue
            self.titlelLabel.text = _hotRecommonModel?.title
            self.bottomDescLabel.text = "\(_hotRecommonModel!.replies)" + "回复  " + "\(_hotRecommonModel!.author)" + "  发表于" + "\(_hotRecommonModel!.fname)"
            //重新设置frame
            
            self.titlelLabel.frame = CGRect.init(x: 10, y: 5, width: (_hotRecommonModel?.titleSize.width)!, height: (_hotRecommonModel?.titleSize.height)!)
            self.bottomDescLabel.top = self.titlelLabel.bottom+10;
            
        }
    }
    
    
    fileprivate lazy var titlelLabel:UILabel = {
        let titleLabel:UILabel = UILabel.init(frame: CGRect.init(x: 10, y: 5, width: KScreen_W-20, height: 30))
        titleLabel.font = UIFont.systemFont(ofSize: 16)
        titleLabel.numberOfLines = 0
        return titleLabel
    }()
    
    fileprivate lazy var bottomDescLabel:UILabel = {
        let bottomDescLabel:UILabel = UILabel.init(frame: CGRect.init(x: 10, y: self.titlelLabel.bottom+10, width: KScreen_W-20, height: 15))
        bottomDescLabel.font = UIFont.systemFont(ofSize: 12)
        bottomDescLabel.textColor = UIColor.gray
        bottomDescLabel.numberOfLines = 0
        return bottomDescLabel
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.contentView.addSubview(self.titlelLabel)
        self.contentView.addSubview(self.bottomDescLabel)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
