//
//  HotRecommonViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/5.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class HotRecommonViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var listArray:[HotRecommonModel] = [HotRecommonModel]()
    
    fileprivate lazy var hotRecommonTableView:UITableView = {
        let hotRecommonTableView:UITableView = UITableView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: KScreen_H-64-49), style: .plain)
        hotRecommonTableView.dataSource = self
        hotRecommonTableView.delegate = self
        hotRecommonTableView.register(HotRecommonCell.self, forCellReuseIdentifier: "HotRecommonCell")
        return hotRecommonTableView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white
        
        self.view.addSubview(self.hotRecommonTableView)
        
        loadData()
    }

    
    override func loadData() {
        
        let urlStr = baseURL + HotGameZoneURL + "/" + "1" + "/" + "20"
        
        NetworkTools.requestData(.get, URLString: urlStr, parameters: nil, finishedCallback: {result in
            
            guard let resultDict = result as? [String : NSObject] else {
                return
            }
            guard let info = resultDict["info"] as? [String : NSObject] else {
                return
            }
            guard let threadListDict = info["threadList"] as? [NSObject] else {
                return
            }
            //            let resultDict = result as? [String : NSObject]
            //            let info = (resultDict?["info"])! as! [NSObject]
            for dic in threadListDict{
                let model = HotRecommonModel.init(dict: dic as! [String : NSObject])
                self.listArray.append(model)
            }
            print(self.listArray.count)
            self.hotRecommonTableView.reloadData()
        })
        
    }
    
    //MARK: -- UITableViewDelegate
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let hotRecommonModel = self.listArray[indexPath.row]
        return hotRecommonModel.cellHeight
    }
    
    //MARK: -- UITableViewDataSource
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return self.listArray.count
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "HotRecommonCell") as! HotRecommonCell
        cell.hotRecommonModel = self.listArray[indexPath.row]
        
        return cell
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



