//
//  KaienCornerViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/12/5.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class KaienCornerViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {
    
    var listArray:[[NSObject]] = []
    var sectionTitleArray:[String] = []
    
    
    fileprivate lazy var collectionView:UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        flowLayout.itemSize = CGSize.init(width: KScreen_W/2, height: 80)
        flowLayout.headerReferenceSize = CGSize(width: KScreen_W, height: 30)
        
        let collectionView:UICollectionView = UICollectionView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: KScreen_H-49-64), collectionViewLayout: flowLayout)
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.backgroundColor = RGB(R: 242, G: 242, B: 242, A: 1)
        
        collectionView.register(LovePlayCell.self, forCellWithReuseIdentifier: "kaien")
        
        collectionView.register(LovePlaySectionView.self, forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "kaienSection")
        return collectionView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(self.collectionView)
        
        loadData()
    }
    
    override func loadData() {
        let urlStr = baseURL + ZoneDiscuzURL + "/1"
        
        weak var weakSelf = self
        NetworkTools.requestData(.get, URLString: urlStr, parameters: nil, finishedCallback: {result in
            print(result)
            guard let resultDict = result as? [String : NSObject] else {
                return
            }
            guard let info = resultDict["info"] as? [String:NSObject] else {
                return
            }
            guard let discuzList = info["discuzList"] as? [NSObject] else {
                return
            }
            for dict in discuzList{
                var arr:[LovePlayModel] = [LovePlayModel]()
                
                guard let dict = dict as? [String : NSObject] else {
                    return
                }
                guard let detailList = dict["detailList"] as? [NSObject] else {
                    return
                }
                
                guard let typeDict = dict["type"] as? [String:NSObject] else {
                    return
                }
                
                for detialDic in detailList{
                    arr.append(LovePlayModel.init(dict: detialDic as! [String : NSObject]))
                }
                weakSelf?.listArray.append(arr)
                weakSelf?.sectionTitleArray.append(typeDict["typeName"] as! String)
                
            }
            weakSelf?.collectionView.reloadData()
            //            print(weakSelf?.listArray.count as Any)
            
        })
    }
    
    //分组头部、尾部
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        switch kind{
        case UICollectionElementKindSectionHeader:
            let v = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "kaienSection", for: indexPath as IndexPath) as! LovePlaySectionView
            v.titleLabel.text = self.sectionTitleArray[indexPath.section]
            return v
        default:
            return LovePlaySectionView()
        }
    }
    //返回分组的头部视图的尺寸，在这里控制分组头部视图的高度
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: KScreen_W, height: 30)
    }
    
    
    //MARK: -- UICollectionViewDataSource
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        let arr:[LovePlayModel] = self.listArray[section] as! [LovePlayModel]
        return arr.count
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "kaien", for: indexPath) as! LovePlayCell
        let arr:[LovePlayModel] = self.listArray[indexPath.section] as! [LovePlayModel]
        
        cell.lovePlayModel = arr[indexPath.row]
        
        return cell
    }
    
    public func numberOfSections(in collectionView: UICollectionView) -> Int{
        return self.listArray.count
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
