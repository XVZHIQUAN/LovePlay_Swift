//
//  CommunityViewController.swift
//  LovePlay_Swift
//
//  Created by zhiquan.xu on 16/11/28.
//  Copyright © 2016年 Gemall. All rights reserved.
//

import UIKit

class CommunityViewController: UIViewController ,NewsPageTopViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate{

    fileprivate lazy var topView:NewsPageTopView = {
        let topView = NewsPageTopView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: 44), titleArray: ["热门推荐","爱玩社区","凯恩之角"])
        topView.delegate = self
        return topView
    }()
    
    fileprivate lazy var comCollectionView:UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize.init(width: KScreen_W, height: KScreen_H-64-49)
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        
        let comCollectionView = UICollectionView.init(frame: CGRect.init(x: 0, y: 0, width: KScreen_W, height: KScreen_H-64-49), collectionViewLayout: flowLayout)
        comCollectionView.backgroundColor = UIColor.white
        comCollectionView.dataSource = self
        comCollectionView.delegate = self
        comCollectionView.showsVerticalScrollIndicator = false
        comCollectionView.showsHorizontalScrollIndicator = false
        comCollectionView.isPagingEnabled = true
        comCollectionView.bounces = false
        
        comCollectionView.register(NewsVCCell.self, forCellWithReuseIdentifier: "comVC")
        
        return comCollectionView
        
        
    }()
    
    fileprivate var vcArray:[UIViewController] = {
        let vcArray:[UIViewController] = [HotRecommonViewController(),LovePlayViewController(),KaienCornerViewController()]
        
        
        return vcArray
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.titleView = self.topView
        
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(self.comCollectionView)
    }
    
    
    //MARK: - NewsPageTopViewDelegate
    
    func newsPageTopViewWithTag(view: NewsPageTopView, tag: Int) {
        self.comCollectionView.scrollToItem(at: IndexPath.init(row: tag, section: 0), at: .centeredHorizontally, animated: true)
    }
    
    
    //MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return self.vcArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "comVC", for: indexPath) as! NewsVCCell
        
        for view:UIView in cell.contentView.subviews {
            view.removeFromSuperview()
        }
        
        cell.cellVC = self.vcArray[indexPath.row]
        cell.cellVC?.view.frame = CGRect.init(x: 0, y: 0, width: KScreen_W, height: self.view.height)
        cell.contentView.addSubview((cell.cellVC?.view)!)
        
        return cell
    }
    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let offset = self.comCollectionView.contentOffset.x/KScreen_W
        self.topView.selectOnePage(pageIndex: Int(offset))
    }
    
    
    
    func loadUI() {
        self.view.addSubview(self.comCollectionView)
        for vc:UIViewController in self.vcArray {
            self.addChildViewController(vc)
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
